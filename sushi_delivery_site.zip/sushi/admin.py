
from django.contrib import admin
from .models import Sushi

admin.site.register(Sushi)
