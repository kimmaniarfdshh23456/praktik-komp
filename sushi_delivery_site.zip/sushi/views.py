
from django.shortcuts import render
from .models import Sushi

def home(request):
    sushis = Sushi.objects.all()
    return render(request, 'sushi/home.html', {'sushis': sushis})
